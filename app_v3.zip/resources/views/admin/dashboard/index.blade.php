@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-body">
                <p>Halaman Dashboard</p>
            </div>
        </div>
    </div>
</div>
@endsection