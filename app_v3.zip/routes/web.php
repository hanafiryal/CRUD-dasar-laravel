<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\KategoriController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/test', function() {
    return view('test', ['pesan' => 'Ini adalah pesan yang ditampilkan dari variable dari route']);
});

Route::get('/admin/dashboard', [DashboardController::class, 'index'])
    ->name('admin.dashboard');

// Kategori
Route::get('/admin/kategori', [KategoriController::class, 'index'])->name('admin.kategori');
Route::post('/admin/kategori/simpan', [KategoriController::class, 'store'])->name('admin.simpan_kategori');
Route::get('/admin/kategori/edit/{id}', [KategoriController::class, 'edit'])->name('admin.edit_kategori');
Route::patch('/admin/kategori/update/{id}', [KategoriController::class, 'update'])->name('admin.update_kategori');
Route::delete('/admin/kategori/hapus/{id}', [KategoriController::class, 'destroy'])->name('admin.hapus_kategori');