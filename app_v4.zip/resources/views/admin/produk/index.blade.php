@extends('admin.layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                @include('admin.produk.create')
            </div>
            <div class="card-body">
                <form action="{{ url()->current() }}">
                    <div class="row mb-2">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-check-label mr-1" for="limit">
                                    Show 
                                </label>
                                <select name="limit" class="custom-select custom-select-sm form-control form-control-sm col-2" aria-controls="limit">
                                    <option value="10" @if($limit == 10)selected @endif>10</option>
                                    <option value="25" @if($limit == 25)selected @endif>25</option>
                                    <option value="50" @if($limit == 50)selected @endif>50</option>
                                    <option value="100" @if($limit == 100)selected @endif>100</option>
                                </select>
                                <label class="form-check-label ml-1" for="limit">
                                    entries 
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="float-right">
                                <div class="form-inline">
                                    <label class="form-check-label mr-1" for="search">
                                        Search: 
                                    </label>
                                    <div class="input-group">
                                    <input type="search" name="search" class="form-control form-control-sm" value="{{ $_GET['search'] ?? '' }}" placeholder="Ketik kata pencarian..." aria-controls="search">
                                    <span class="input-group-append">
                                        <button type="submit" class="btn btn-sm btn-info">Go!</button>
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="table">
                    <table class="table table-bordered table-hover table-sm">
                        <thead>
                            <tr>
                                <th width="1%">No</th>
                                <th>Nama Produk</th>
                                <th>status</th>
                                <th width="20%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($produk as $no => $data)
                            <tr>
                                <td>{{ $no + 1; }}</td>
                                <td>{{ $data->nama_produk }}</td>
                                <td>{{ $data->status }}</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-info" data-toggle="modal" data-target="#Detail{{ $data->id_produk }}">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                    
                                    <a href="{{ route('admin.edit_produk', $data->id_produk) }}" class="btn btn-sm btn-outline-warning">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>

                                    <button type="button" class="btn btn-sm btn-outline-danger" data-toggle="modal" data-target="#Hapus{{ $data->id_produk }}">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </td>

                                @include('admin.produk.detail')
                                @include('admin.produk.delete')
                            </tr>
                            @endforeach

                            @if(empty($produk->total()))
                            <tr>
                                <td colspan="4" class="text-center">Data masih kosong</td>
                            </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection